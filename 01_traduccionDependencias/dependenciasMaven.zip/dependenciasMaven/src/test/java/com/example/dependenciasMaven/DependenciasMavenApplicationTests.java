package com.example.dependenciasMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependenciasMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
