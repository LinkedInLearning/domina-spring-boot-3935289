package com.example.dependenciasMaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DependenciasMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DependenciasMavenApplication.class, args);
	}

}
