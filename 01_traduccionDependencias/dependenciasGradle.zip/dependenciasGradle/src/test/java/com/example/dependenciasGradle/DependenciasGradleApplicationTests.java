package com.example.dependenciasGradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependenciasGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
