package com.example.dependenciasGradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DependenciasGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DependenciasGradleApplication.class, args);
	}

}
